const { createProxyMiddleware } = require('http-proxy-middleware');

module.exports = function(app) {
  app.use(
    '/blocks',
    createProxyMiddleware({
      target: 'http://blockchain.info',
      changeOrigin: true,
      logLevel: 'debug',
   
    })
  );
};
