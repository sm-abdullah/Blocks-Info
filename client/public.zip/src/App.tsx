import React from 'react';
import logo from './logo.svg';
import './App.css';
import BlockListingContainer from './BlockListing/BlockListingContainer';
import Dialogbox from './DialogBox';




function App() {
  return (
    <div className="App">
 
      <BlockListingContainer />
    </div>

  );
}

export default App;
